//
//  ViewController.swift
//  PanGesture
//
//  Created by SHUBHAM AGARWAL on 11/07/18.
//  Copyright © 2018 SHUBHAM AGARWAL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    
    
    @IBOutlet weak var customView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.view.addSubview(customView)
        //customView.addSubview(UIImageView)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(onClickImageView))
        imgView.addGestureRecognizer(panGesture)
        
       
        // Do any additional setup after loading the view, typically from a nib.
    }

//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }

    @objc func onClickImageView(recogizer: UIPanGestureRecognizer) {
        self.view.bringSubview(toFront: self.imgView)
        let translation = recogizer.translation(in: self.view)
        
        
        imgView.center = CGPoint(x: imgView.center.x + translation.x, y: imgView.center.y + translation.y)
        
        
        recogizer.setTranslation(CGPoint.zero, in: self.view)
    }
    
 
    
}

