# resizeRectangleOnTouchDrag
Resize Rectangle on Touch &amp; Drag.

This is a simple example App to show how a rectangle can be resized by touch & drag.
As recommended when using AutoLaout, the constraints of the rectangle are animated rather than the actual size of the rect.
Works basically in portrait and landscape mode, too.

## Build with
* Xcode 10.1
* Swift 4.2


## Installation
1. Download Zip file and open ResizeRectangle.xcodeproj
2. Chose build target iOS Simulator or iPhone
3. Run app by selecting Build button or Command + R

## Licensing:
Public Domain

## Answer to this question on Stackoverflow
https://stackoverflow.com/questions/8460119/how-to-resize-uiview-by-dragging-from-its-edges


